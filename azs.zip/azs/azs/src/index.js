import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Provider } from 'react-redux'
import configureStore from './store/configureStore'
import { addUser } from './actions/RegAction'
import {addTodo} from './actions/TodoAction'
import moment from 'moment'

const store = configureStore();

console.log(store.getState());

store.dispatch(addUser({ name: 'damon', email: 'msatishvj001@gmail.com' }));
store.dispatch(addUser({ name: 'Sat', email: 'sci@gmail.com' }));
store.dispatch(addTodo({ task: 'Complete the Assingement Sat', date: moment().format("l") }));
store.dispatch(addTodo({ task: 'Hola sunday the Assingement Sat', date: moment().format("l") }));
// store.dispatch(setNameFilter({ name: 'sat' }));

const state = store.getState();
console.log(state);
// const visibleData = getVisibleData(state.students, state.filters)
// console.log( visibleData);
ReactDOM.render(
    <Provider store={store}>
        <App />
    </Provider>
    , document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
