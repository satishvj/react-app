import { createStore, combineReducers } from "redux";
import UserReducer from '../reducers/User';
import TodoReducer from '../reducers/TodoReducer'

export default () => {
    const store = createStore(
        combineReducers({
            users: UserReducer,
            todos: TodoReducer
        })
    );
    return store;
}