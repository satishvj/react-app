import React from 'react';
import './App.css';
import UserList from './components/UserList'
import AddUserDetailsPage from './components/AddUserPage'
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import Header from './components/Header'
import EditUserDetailsPage from './components/EditUserDetailsPage';
import TodoList from './components/TodoList';
import Todos from './components/Todos';
import AddTodos  from './components/AddTodos'

const App = (props) => {

  return (
    <div className="App">
      <BrowserRouter>
        <div>
          <Header />
          <Switch>
            <Route path="/" component={UserList} exact={true} />
            <Route path="/create" component={AddUserDetailsPage} exact={true}/>
            <Route path="/createTodo" component={AddTodos} exact={true}/>
            <Route path="/edit/:id" component={EditUserDetailsPage} />
            <Route path="/todoList" component={TodoList}/>
            <Route path="/todos" component={Todos}/>
             {/* <Route path="/editTodo/:id" component={EditTodos}/> */}
          </Switch>
        </div>
      </BrowserRouter>
    </div>
  );
}

export default App;
