import uuid from 'node-uuid';

// ADD_User
export const addUser = (
  {
    name = '',
    email = ''
  } = {}
) => ({
  type: 'ADD_USER',
  user: {
    id: uuid(),
    name,
    email
  }
});

export const existUser = (name, subject, updates) => ({
  type: 'EXIST_USER',
  name,
  subject,
  updates
});

// REMOVE_User
export const removeUser = ({ id } = {}) => ({
  type: 'REMOVE_USER',
  id
});

// EDIT_User
export const editUser = (id, updates) => ({
  type: 'EDIT_USER',
  id,
  updates
});
