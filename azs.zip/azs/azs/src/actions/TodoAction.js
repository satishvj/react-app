import uuid from 'node-uuid';

export const addTodo = (
    {
        task = '',
        date = null
    } = {}
) => ({
    type: 'ADD_TODO',
    todo: {
        id: uuid(),
        task,
        date
    }
});

// REMOVE_User
export const deleteTodo = ({ id } = {}) => ({
    type: 'DELETE_TODO',
    id
  });
  
  // EDIT_User
  export const editTodo = (id, updates) => ({
    type: 'EDIT_TODO',
    id,
    updates
  });
  