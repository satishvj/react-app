import React from 'react';
import 'antd/dist/antd.css';
import { Form, DatePicker, Input, Button, Modal } from 'antd';
import moment from 'moment';
import TodoList from './TodoList'

 
const dateFormat = 'MM/DD/YYYY';
class Todo extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            items: props.todo ? props.todo : [],
            todos: props.todo ? props.todo : { task: '', date: moment() },
            task: props.todo ? props.todo.task : '',
            date: props.todo ? props.todo.date : moment(),
            error: '',
            btnLbl: props.todo ? 'Update Todo' : 'Add Todo',
            visible: false,
            confirmLoading: false
        }
        this.handleInput = this.handleInput.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.onChangeDate = this.onChangeDate.bind(this);
        this.showModal = this.showModal.bind(this);
        this.handleCancel = this.handleCancel.bind(this);
    }
    showModal = () => {
        this.setState({
            visible: true,
        });
    };

    handleCancel = () => {
        this.setState({
            visible: false,
        });
    };

    handleInput(e) {
        const value = e.target.value;
        console.log('value:' + value);
        this.setState({
            [e.target.name]: value
        })
    }
    onChangeDate(date, datestrig) {
        console.log(datestrig);
        this.setState({
            date: date
        })
        console.log(this.state.date);
    }
    
    handleSubmit(e) {
        e.preventDefault();
        setTimeout(() => {
            this.setState({
              visible: false,
              confirmLoading: false,
            });
          }, 2000);
          this.setState({
            confirmLoading: true,
          });

        if (!this.state.task || !this.state.date) {
            //error
            this.setState(() => ({ error: 'Please Enter all Fields' }))
        } else {
            this.props.onSubmit({
                task: this.state.task,
                date: this.state.date.format("l")
              })

            this.setState({
                task: '',
                date: moment(),
            })
            console.log('after submit');
        }
    }

    render() {
        const { visible, confirmLoading } = this.state;
        return (
            <div className="container">
                <Button type="primary" onClick={this.showModal}>
                    {this.state.btnLbl}
                </Button>
                <Modal
                    title={this.state.btnLbl}
                    visible={visible}
                    onOk={this.handleSubmit}
                    confirmLoading={confirmLoading}
                    onCancel={this.handleCancel}
                >
                    <Input
                        type="text"
                        placeholder="Task"
                        name="task"
                        value={this.state.task}
                        onChange={this.handleInput}
                        style={{padding:'1%',margin:'1%',borderRadius:'4px'}}
                    />
                    <DatePicker style={{padding:'1%',margin:'1%',borderRadius:'4px'}} name="date" defaultValue={moment(this.state.date, dateFormat)} showTime onChange={this.onChangeDate} format={dateFormat} />
                    
        </Modal>
                <TodoList todos={this.state.todos} />
            </div>
        );
    }
}

const Todos = Form.create({})(Todo);

export { Todos };
export default Todos;
