import React from 'react'
import { connect } from 'react-redux'
import { Button, Table } from 'react-bootstrap';
import { removeUser } from '../actions/RegAction'
import { Link } from 'react-router-dom';
import AddUserPage from './AddUserPage';


const UserList = (props) => {
    return (
        <div>
            <h1>
                User List
     </h1>
            <Table responsive>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>EmailId</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    {props.users.length > 0 ? (
                        props.users.map(u => (
                            <tr key={u.id}>
                                <td>{u.name}</td>
                                <td>{u.email}</td>
                                <td>
                                    <Link to={`/edit/${u.id}`}>
                                        <Button variant="outline-primary">Edit</Button>
                                    </Link>
                                    <Button variant="outline-primary" onClick={() => {
                                        props.dispatch(removeUser({ id: u.id }));
                                    }}>Delete</Button>
                                </td>
                            </tr>
                        ))
                    ) : (
                            <tr>
                                <td colSpan={3}>No users</td>
                            </tr>
                        )}

                </tbody>
            </Table>
            <AddUserPage />
            {/* <NavLink to="/create" activeClassName="is-active">Add New User</NavLink> */}
        </div>
    );
};

const mapStateToProps = (state) => {
    return {
        users: state.users
    };
};

export default connect(mapStateToProps)(UserList);
