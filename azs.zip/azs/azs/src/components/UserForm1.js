import React from 'react'
import {Form, Button,Input} from 'antd';
import '../App.css';
import 'antd/dist/antd.css';

// export default class UserForm extends React.Component {
//     constructor(props) {
//         super(props);
//         this.state = {
//             name: props.user ? props.user.name : '',
//             email: props.user ? props.user.email : '',
//             error: '',
//             btnLbl: props.user ? 'Update User' : 'Add User',
//             existUser: props.user ? true : false
//         }
//     }

//     onChangeName = (e) => {
//         const name = e.target.value;
//         this.setState(() => ({ name }));
//     }
//     onChangeEmailId = (e) => {
//         const email = e.target.value;
//         this.setState(() => ({ email }));
//     }

//     onSubmit = (e) => {
//         e.preventDefault();
//         if ((!this.state.name  || !this.state.email) && !this.state.existUser) {
//             //error
//             this.setState(() => ({ error: 'Please Enter all Fields' }))
//         } else {
//             //clear error
//             this.setState(() => ({ error: '' }))
//             console.log('submitted');
//             this.props.onSubmit({
//                 name: this.state.name,
//                 email: this.state.email
//             })
//         }
//     }

//     render() {
//         return (
//             <div className="inp-flds">
//                 {this.state.error && <p>{this.state.error}</p>}
//                 <Form layout="inline" onSubmit={this.onSubmit}>
//                 <Form.Item>
//                     <Input
//                         type="text"
//                         placeholder="Name"
//                         value={this.state.name}
//                         onChange={this.onChangeName}
//                     />
//                      </Form.Item>
//                      <Form.Item>
//                     <Input
//                         type="email"
//                         placeholder="EmailId"
//                         value={this.state.email}
//                         onChange={this.onChangeEmailId}
//                         />
//                      </Form.Item >
//                      <Form.Item>

//                     <Button type='primary'>{this.state.btnLbl}</Button>
                
//                     </Form.Item>
//                     </Form>
//             </div>
//         )
//     }
// }



function hasErrors(fieldsError) {
    return Object.keys(fieldsError).some(field => fieldsError[field]);
}

class UserF extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            name: props.user ? props.user.name : '',
            email: props.user ? props.user.email : '',
            error: '',
            btnLbl: props.user ? 'Update User' : 'Add User',
            existUser: props.user ? true : false
        }
    }

    onChangeName = (e) => {
        const name = e.target.value;
        this.setState(() => ({ name }));
    }
    onChangeEmailId = (e) => {
        const email = e.target.value;
        this.setState(() => ({ email }));
    }

  

    componentDidMount() {
        // To disabled submit button at the beginning.
        this.props.form.validateFields();
    }

    
    handleSubmit(e) {
        e.preventDefault();

        if (!this.state.task || !this.state.date) {
            //error
            this.setState(() => ({ error: 'Please Enter all Fields' }))
        } else {
            this.setState(() => ({ error: '' }))
            console.log('submitted');
            this.props.onSubmit({
                name: this.state.name,
                email: this.state.email
            })
            console.log('after submit');
            console.log(this.state.items);
        }
    }

    render() {
        const { getFieldsError, getFieldError, isFieldTouched } = this.props.form;

        // Only show error after a field is touched.
        const nameError = isFieldTouched('name') && getFieldError('name');
        const emailError = isFieldTouched('email') && getFieldError('email');
        return (
            <Form layout="inline" onSubmit={this.handleSubmit}>
                <Form.Item validateStatus={nameError ? 'error' : ''} help={nameError || ''}>
                    {
                       <Input
                       type="text"
                       placeholder="Name"
                       value={this.state.name}
                       onChange={this.onChangeName}
                   />}
                </Form.Item>
                <Form.Item validateStatus={emailError ? 'error' : ''} help={emailError || ''}>
                    {
                        <Input
                        type="email"
                        placeholder="EmailId"
                        value={this.state.email}
                        onChange={this.onChangeEmailId}
                        />
                    }
                </Form.Item>
                <Form.Item>
                    <Button type='primary'>{this.state.btnLbl}</Button>
                </Form.Item>
            </Form>
        );
    }
}

const UserFor = Form.create({})(UserF);

export { UserFor };
export default UserFor;
