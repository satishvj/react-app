import React from 'react';
import { Link } from 'react-router-dom';

const Header = () => (
  <header>
    <div className="flex-container" style={{ padding: '1%', display: 'flex', height: '50px', alignItems: 'center' }}>

      <nav className="navbar navbar-default navbar-static-top">
        <ul className="nav nav-pills">
          {/* Check the Css section for the selector */}
          <li><Link to="/createTodo" >Todos</Link></li>
          <li><Link to="/" >UserReg</Link></li>
        </ul>
      </nav>
    </div>

  </header>
);

export default Header;
