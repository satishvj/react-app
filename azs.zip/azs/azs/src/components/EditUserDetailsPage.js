import React from 'react'
import { connect } from 'react-redux'
import UserForm from './UserForm'
import { editUser} from '../actions/RegAction'
 
const EditUserDetailsPage = (props) => {
    return (
         <UserForm 
         user={props.users}
         onSubmit={(user)=>{
             console.log('update',user);
             props.dispatch(editUser(props.users.id, user));
             props.history.push('/');
         }}
         />
    );
};

const mapStateToProps = (state, props) => {
    return {
        users: state.users.find((user) => user.id === props.match.params.id)
    }
}
export default connect(mapStateToProps)(EditUserDetailsPage)