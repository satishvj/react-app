import React from 'react';
import { Icon } from 'antd';
import { connect } from 'react-redux';
import { deleteTodo } from '../actions/TodoAction'
import {Link} from 'react-router-dom'

const listStyle = {
    margin: '20px auto',
    backgroundColor: '#eee',
    width: '50%',
    borderRadius: '5px',
    padding: '10px',
    textAlign: 'left'

}

const TodoList = (props) => {
    const todos = props.todos;
    const listItems = todos.map(todo => {
        return <div key={todo.id}>
            <p style={listStyle} >{todo.task} <span style={{ paddingLeft: '1%' }}>{todo.date}</span>
                <Icon type="delete"
                    style={{ paddingLeft: "3%", float: 'right' }}
                    onClick={() => {
                        props.dispatch(deleteTodo({
                            id: todo.id
                        }))
                    }}
                />
            </p>
        </div>
    })
    return (
        <div className="col-6">{listItems}
        
        {/* <NavLink to="/createTodo" activeClassName="is-active">Add Todos </NavLink> */}
        </div>
    )
}

const mapStateToProps = (state) => {
    return {
        todos: state.todos
    };
};

export default connect(mapStateToProps)(TodoList);