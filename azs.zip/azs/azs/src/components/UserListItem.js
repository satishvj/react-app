import React from 'react'
import { Button, Table } from 'react-bootstrap';

const UserListItem = ({ name, subject, score }) => (
    <div>
        <Table responsive>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>{name}</td>
                    <td>{email}</td>
                    <td>
                        <Button variant="outline-primary">Edit</Button>
                        <Button variant="outline-primary">Delete</Button>
                    </td>
                </tr>

            </tbody>
        </Table>
    </div>
);

export default UserListItem;