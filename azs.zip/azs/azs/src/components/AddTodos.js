import React from 'react'
import { connect } from 'react-redux'
import { addTodo } from '../actions/TodoAction';
import Todos from './Todos';

const AddTodos = (props) => (
    <div>
        <h1>Add Todos Page</h1>
        <Todos
         onSubmit={(todo) => {
            console.log('from AddUser' + todo)
            props.dispatch(addTodo(todo));
            props.history.push('/createTodo');
        }}
        />
    </div>
);

export default connect()(AddTodos);