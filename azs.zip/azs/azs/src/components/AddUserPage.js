import React from 'react'
import { connect } from 'react-redux'
import UserForm from './UserForm'
import { addUser } from '../actions/RegAction'

const AddUserPage = (props) => (
    <div>
        <UserForm
            onSubmit={(user) => {
                console.log('from AddUser' + user)
                props.dispatch(addUser(user));
            }}
        />
    </div>
);

export default connect()(AddUserPage);