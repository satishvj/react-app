import React from 'react'
import '../App.css';
import { Modal, Button } from 'antd';

export default class UserForm extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      name: props.user ? props.user.name : '',
      email: props.user ? props.user.email : '',
      error: '',
      btnLbl: props.user ? 'Update User' : 'Add User',
      existUser: props.user ? true : false,
      visible: false,
      confirmLoading: false
    }
  }
  showModal = () => {
    this.setState({
      visible: true,
    });
  };

  handleCancel = () => {
    this.setState({
      visible: false,
    });
  };

  onChangeName = (e) => {
    const name = e.target.value;
    this.setState(() => ({ name }));
  }
  onChangeEmailId = (e) => {
    const email = e.target.value;
    this.setState(() => ({ email }));
  }

  onSubmit = (e) => {
    e.preventDefault();
    setTimeout(() => {
      this.setState({
        visible: false,
        confirmLoading: false,
      });
    }, 2000);
    this.setState({
      confirmLoading: true,
    });
    if ((!this.state.name || !this.state.email) && !this.state.existUser) {
      //error
      this.setState(() => ({ error: 'Please Enter all Fields' }))
    } else {
      //clear error
      this.setState(() => ({ error: '' }))
      console.log('submitted');
      this.props.onSubmit({
        name: this.state.name,
        email: this.state.email
      })
      this.setState({
        name:'',
        email:''
      })
    }
  }

  render() {
    const { visible, confirmLoading } = this.state;

    return (
      <div className="inp-flds">
        {this.state.error && <p>{this.state.error}</p>}
        <Button type="primary" onClick={this.showModal}>
        {this.state.btnLbl}
        </Button>
        <Modal
          title={this.state.btnLbl}
          visible={visible}
          onOk={this.onSubmit}
          confirmLoading={confirmLoading}
          onCancel={this.handleCancel}
        >
          <input
            type="text"
            placeholder="Name"
            value={this.state.name}
            onChange={this.onChangeName}
            style={{padding:'1%',margin:'1%',borderRadius:'4px'}}
          />
          <input
            type="email"
            placeholder="EmailId"
            value={this.state.email}
            onChange={this.onChangeEmailId}
            style={{padding:'1%',margin:'1%',borderRadius:'4px'}}
          />
        </Modal>
      </div>
    )
  }
}