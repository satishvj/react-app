import uuid from 'node-uuid';

const initialState = [];

const UserR = (state = initialState, action) => {
    switch (action.type) {
        case 'ADD_USER':
            return [
                ...state,
                action.user
            ];
        case 'EXIST_USER':
            return state.map((user) => {
                if (user.name.toLowerCase() === action.name.toLowerCase() && user.email.toLowerCase() === action.email.toLowerCase()) {
                    return {
                        ...user,
                        ...action.updates
                    };
                } else {
                    const id = uuid();
                    return [
                        ...state,
                        action.updates,
                        action.updates.id = id

                    ];
                };
            });
        case 'REMOVE_USER':
            return state.filter(({ id }) => id !== action.id);
        case 'EDIT_USER':
            return state.map((user) => {
                if (user.id === action.id) {
                    return {
                        ...user,
                        ...action.updates
                    };
                } else {
                    return user;
                };
            });
        default:
            return state;
    }
};

export default UserR; 